SA_PHYHBTU
==========
Your uploaded SA_PHYHBTU icon is included in 192x192 and 512x512 sizes.

Files:
- index.html
- manifest.json
- sw.js
- icons/icon-192.png
- icons/icon-512.png

The HTML already references manifest.json and the 192x192 icon.
Serve this folder from HTTPS to enable PWA installation in Chrome.
